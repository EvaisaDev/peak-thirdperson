# Third Person Toggle   
**A mod that adds a third person toggle button**    
The button is configurable with the config file, V by default.   
You can zoom in and out slightly with scroll wheel.     
   
![Third Person Camera](https://share.evaisa.dev/1ZvgqsLFc.jpg)